import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:mobile_project/Appointments.dart';
import 'package:http/http.dart' as http;
import 'package:mobile_project/Calendar.dart';
import 'package:mobile_project/Profil.dart';

List data = [];
List Favorite=[];
class UsersScreen extends StatefulWidget {
  const UsersScreen({Key? key}) : super(key: key);

  @override
  _UsersScreenState createState() => _UsersScreenState();
}

class _UsersScreenState extends State<UsersScreen> {
  Future<List> getData() async {
    final response = await http
        .get(Uri.parse('https://mobilebackend.onrender.com/api/users'));
    data = json.decode(response.body);
    return data;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      floatingActionButton: FloatingActionButton(
          backgroundColor: Color.fromRGBO(0, 0, 128, 1),
          onPressed: () {},
          child: const Icon(Icons.add)),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(0, 0, 128, 1),
        title: const Text("House Keeper"),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.search))],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: getData(),
        builder: (context, snapshot) {
          if (snapshot.data == null) {
            return Center(
              child: const CircularProgressIndicator(),
            );
          } else {
            return ListView.builder(
                padding: EdgeInsets.only(top: 40, bottom: 60),
                itemCount: data.length == 0 ? 0 : data.length,
                itemBuilder: (context, index) {
                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(
                        radius:28,
                        backgroundImage: NetworkImage(
                          "https://firebasestorage.googleapis.com/v0/b/mobileproject-ee2ad.appspot.com/o/258606681_2573591256117688_6924124459095621389_n.jpg?alt=media&token=db204ef0-7f3e-4770-be6b-c51727db4c0c"
                        ),
                      ),
                      title:Text(data[index]["name"]),
                      subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          SizedBox(height: 10),
                          Text(data[index]["location"]),
                          SizedBox(height: 10), // Add some spacing between the sub titles
                          Text(data[index]["phoneNumber"]),
                          SizedBox(height: 10),
                          Visibility(
                            visible:
                            data[index]["rate"] ==0,
                            child: Padding(
                              padding:
                              const EdgeInsets.only(right: 5),
                              child:Row(
                                children: [
                                  Column(
                                    children: [
                                      Text(
                                        "New",
                                        style:
                                        TextStyle(color: Colors.blueAccent),
                                      ),
                                    ],
                                  )
                                ],
                              ),

                            ),
                          ),
                          Visibility(
                            visible:
                            data[index]["rate"] !=0,
                            child: Padding(
                              padding:
                              const EdgeInsets.only(left:0),
                              child:Row(
                                children: [
                                  Column(
                                    children: [
                                      Text(
                                        "${data[index]["rate"]}",
                                        style:
                                        TextStyle(color: Colors.blueAccent),
                                      ),
                                    ],
                                  ),
                                  Column(
                                    children: [
                                      Icon(Icons.star,color:Colors.blueAccent,size:15)
                                    ],

                                  ),
                                ],
                              ),

                            ),
                          ),
// Add some spacing between the sub titles
                        ],
                      ),
                      trailing:Row(
                          mainAxisSize: MainAxisSize.min,
                        children: [
                          IconButton(
                            onPressed: () {
                            },
                            icon :true
                              ? const Icon(Icons.favorite, color: Colors.red)
                              : const Icon(Icons.favorite_border),
                          ),
                        ],
                      ),
                      onTap: (){
                      },
                    ),
                  );
                });
          }
        },
      ),
      bottomNavigationBar: BottomAppBar(
          shape: const CircularNotchedRectangle(),
          color: Color.fromRGBO(0, 0, 128, 1),
          child: IconTheme(
              data: IconThemeData(
                  color: Theme.of(context).colorScheme.onSecondary),
              child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      IconButton(
                        icon: Icon(Icons.home),
                        onPressed: () {},
                      ),
                      IconButton(
                        icon: Icon(Icons.list),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => Appointments()));
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.person),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ProfilePage()));
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.settings),
                        onPressed: () {},
                      ),
                    ],
                  )))),
    );
  }
}
