import 'package:flutter/material.dart';
import 'package:mobile_project/SearchPage.dart';

import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:mobile_project/dashbord.dart';

var currentStep = 0;
Future<User> createUser(
  BuildContext context,
  String name,
  String email,
  String state,
  String password,
  String confirmpassword,
) async {
  if (password != confirmpassword) {
    throw Exception('Wrong password');
  } else {
    try {
      final response = await http.post(
        Uri.parse('https://mobilebackend.onrender.com/api/signup'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, String>{
          'name': name,
          'email': email,
          'state': state,
          'password': password,
        }),
      );
      if (response.statusCode == 200) {
        // If the server did return a 200 OK response,
        // then parse the JSON.
        // return User.fromJson(jsonDecode(response.body));
        Navigator.push(
            context, MaterialPageRoute(builder: (context) => Dashbord()));
        return User(email: "", password: "", name: "", state: "");
      } else {
        // If the server did not return a 201 CREATED response,
        // then throw an exception.
        throw Exception('Failed to signup.');
      }
    } catch (e) {
      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text(
              e.toString(),
              style: TextStyle(
                color: Colors.red,
              ),
            ),
            actions: <Widget>[
              TextButton(
                child: Text('Close'),
                onPressed: () {
                  Navigator.of(context).pop();
                },
              ),
            ],
          );
        },
      );
      return User(email: "", password: "", name: "", state: "");
    }
  }
}

class User {
  final String email;
  final String password;
  final String name;
  final String state;

  const User(
      {required this.email,
      required this.password,
      required this.name,
      required this.state});

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      email: json['email'],
      state: json['state'],
      name: json['name'],
      password: json['password'],
    );
  }
}

class SignupPage extends StatefulWidget {
  @override
  State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final TextEditingController _emailcontroller = TextEditingController();
  final TextEditingController _namecontroller = TextEditingController();
  final TextEditingController _passwordcontroller = TextEditingController();
  final TextEditingController _confirmpasswordcontroller =
      TextEditingController();
  final TextEditingController _statecontroller = TextEditingController();
  final TextEditingController _locationcontroller = TextEditingController();
  final TextEditingController _phoneNumbercontroller = TextEditingController();

  Future<User>? _futureUser;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Signup"),
        centerTitle: true,
        elevation: 0,
        brightness: Brightness.light,
        backgroundColor: Color(0xff0054FF),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(
            Icons.arrow_back_ios,
            size: 20,
            color: Colors.white,
          ),
        ),
      ),
      body: Theme(
        data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(primary: Color(0xff0054FF))),
        child: Stepper(
          type: StepperType.horizontal,
          steps: getSteps(
              _namecontroller,
              _emailcontroller,
              _statecontroller,
              _phoneNumbercontroller,
              _locationcontroller,
              _passwordcontroller,
              _confirmpasswordcontroller),
          currentStep: currentStep,
          onStepContinue: () {
            setState(() {
              if (currentStep != 2) {
                currentStep += 1;
              } else {
                //send Data!

              }
            });
          },
          onStepCancel: () {
            setState(() {
              if (currentStep != 0) {
                currentStep -= 1;
              }
            });
          },
        ),
      ),
    );
  }
}

List<Step> getSteps(
        _namecontroller,
        _emailcontroller,
        _statecontroller,
        _phoneNumbercontroller,
        _locationcontroller,
        _passwordcontroller,
        _confirmpasswordcontroller) =>
    [
      Step(
          isActive: currentStep >= 0,
          title: Text("Step 1"),
          content: Column(
            children: <Widget>[
              TextField(
                controller: _namecontroller,
                decoration: const InputDecoration(hintText: 'Full Name'),
              ),
              TextField(
                controller: _emailcontroller,
                decoration: const InputDecoration(hintText: 'Enter Email'),
              ),
              TextField(
                controller: _statecontroller,
                decoration: const InputDecoration(hintText: 'Enter State'),
              ),
            ],
          )),
      Step(
          isActive: currentStep >= 1,
          title: Text("Step 2"),
          content: Column(
            children: <Widget>[
              TextField(
                controller: _locationcontroller,
                decoration: const InputDecoration(hintText: 'Enter Location'),
              ),
              TextField(
                controller: _phoneNumbercontroller,
                decoration:
                    const InputDecoration(hintText: 'Enter phoneNumber'),
              ),
            ],
          )),
      Step(
          isActive: currentStep >= 2,
          title: Text("Step 3"),
          content: Column(
            children: <Widget>[
              TextField(
                controller: _passwordcontroller,
                decoration: const InputDecoration(hintText: 'Enter Password'),
              ),
              TextField(
                controller: _confirmpasswordcontroller,
                decoration: const InputDecoration(hintText: 'Confirm Password'),
              ),
            ],
          )),
    ];

// we will be creating a widget for text field
Widget inputFile({
  label,
  obscureText = false,
}) {
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: <Widget>[
      Text(
        label,
        style: TextStyle(
            fontSize: 15, fontWeight: FontWeight.w400, color: Colors.black87),
      ),
      SizedBox(
        height: 5,
      ),
      TextField(
        obscureText: obscureText,
        decoration: InputDecoration(
            filled: true,
            contentPadding: EdgeInsets.symmetric(vertical: 0, horizontal: 10),
            enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(),
              borderRadius: BorderRadius.circular(50),
            ),
            border: OutlineInputBorder(
              borderSide: BorderSide(),
              borderRadius: BorderRadius.circular(50),
            )),
      ),
      SizedBox(
        height: 10,
      )
    ],
  );
}
