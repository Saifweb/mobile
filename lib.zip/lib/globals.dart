library my_app;

String type = 'House cleaning';
String id = "";